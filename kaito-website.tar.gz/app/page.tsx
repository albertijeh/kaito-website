import { Header } from './components/Header';
import { Hero } from './components/sections/Hero';
import { SingleJourney } from './components/sections/SingleJourney';
import { KaitoAI } from './components/sections/KaitoAI';
import { ProductOverview } from './components/sections/ProductOverview';
import { SignalIntelligenceAction } from './components/sections/SignalIntelligenceAction';
import { Manifesto } from './components/sections/Manifesto';
import { FAQ } from './components/sections/FAQ';
import { FinalCTA } from './components/sections/FinalCTA';
import { Footer } from './components/Footer';

export default function Home() {
  return (
    <>
      <Header />
      <main>
        <Hero />
        <SingleJourney />
        <KaitoAI />
        <ProductOverview />
        <SignalIntelligenceAction />
        <Manifesto />
        <FAQ />
        <FinalCTA />
      </main>
      <Footer />
    </>
  );
}
