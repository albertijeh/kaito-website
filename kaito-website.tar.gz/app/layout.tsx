import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'Kaito | CRM com IA e Customer Intelligence',
  description:
    'Transforme dados e interações em inteligência. Conheça a Kaito, plataforma de CRM com IA para vendas, automação e gestão da jornada do cliente.',
  keywords: [
    'CRM com IA',
    'Customer Intelligence',
    'Inteligência artificial para vendas',
    'Gestão de leads',
    'Automação de vendas',
  ],
  metadataBase: new URL('https://kaito.com'),
  openGraph: {
    title: 'Kaito — Customer Intelligence potencializada por IA',
    description:
      'Conecte CRM, IA, automação e dados para transformar sinais de clientes em inteligência e ação.',
    type: 'website',
    locale: 'pt_BR',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Kaito | CRM com IA e Customer Intelligence',
    description:
      'Transforme dados e interações em inteligência. Customer Intelligence potencializada por IA.',
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="pt-BR" suppressHydrationWarning>
      <head>
        <meta charSet="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <link rel="icon" href="/favicon.ico" />
      </head>
      <body className="bg-kaito-bg-dark text-kaito-fg-light">
        <div className="flex flex-col min-h-screen">
          <main className="flex-grow">{children}</main>
        </div>
      </body>
    </html>
  );
}
