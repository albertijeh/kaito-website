import React from 'react';
import { Badge } from './Badge';

interface SectionHeaderProps {
  eyebrow?: string;
  title: string;
  subtitle?: string;
  description?: string;
  centered?: boolean;
  className?: string;
}

export const SectionHeader: React.FC<SectionHeaderProps> = ({
  eyebrow,
  title,
  subtitle,
  description,
  centered = true,
  className = '',
}) => {
  return (
    <div className={`${centered ? 'text-center' : ''} ${className}`}>
      {eyebrow && (
        <Badge variant="purple" className="mb-4 justify-center">
          {eyebrow}
        </Badge>
      )}
      <h2 className="text-4xl md:text-5xl font-bold tracking-tight mb-6">
        {title}
      </h2>
      {description && (
        <p className="text-lg text-kaito-text-secondary max-w-2xl mx-auto mb-6 leading-relaxed">
          {description}
        </p>
      )}
      {subtitle && (
        <p className="text-kaito-text-secondary max-w-3xl mx-auto">
          {subtitle}
        </p>
      )}
    </div>
  );
};
