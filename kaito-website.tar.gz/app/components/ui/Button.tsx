import React from 'react';
import Link from 'next/link';

interface ButtonProps {
  variant?: 'primary' | 'secondary' | 'ghost';
  size?: 'sm' | 'md' | 'lg';
  href?: string;
  onClick?: () => void;
  children: React.ReactNode;
  className?: string;
  disabled?: boolean;
  type?: 'button' | 'submit' | 'reset';
  target?: string;
  rel?: string;
}

export const Button = React.forwardRef<
  HTMLButtonElement & HTMLAnchorElement,
  ButtonProps
>(
  (
    {
      variant = 'primary',
      size = 'md',
      href,
      onClick,
      children,
      className = '',
      disabled = false,
      type = 'button',
      target,
      rel,
    },
    ref
  ) => {
    const baseStyles =
      'inline-flex items-center justify-center font-medium transition-all duration-300 rounded-lg focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-kaito-purple';

    const variants = {
      primary:
        'bg-kaito-purple text-kaito-fg-light hover:bg-kaito-purple-light active:bg-kaito-accent disabled:opacity-50 disabled:cursor-not-allowed',
      secondary:
        'border border-kaito-border text-kaito-fg-light hover:border-kaito-purple hover:text-kaito-purple bg-transparent active:bg-kaito-bg-darker disabled:opacity-50 disabled:cursor-not-allowed',
      ghost:
        'text-kaito-text-secondary hover:text-kaito-fg-light bg-transparent active:bg-kaito-bg-darker disabled:opacity-50 disabled:cursor-not-allowed',
    };

    const sizes = {
      sm: 'px-4 py-2 text-sm',
      md: 'px-6 py-3 text-base',
      lg: 'px-8 py-4 text-lg',
    };

    const classes = `${baseStyles} ${variants[variant]} ${sizes[size]} ${className}`;

    if (href) {
      return (
        <Link href={href} className={classes} target={target} rel={rel}>
          {children}
        </Link>
      );
    }

    return (
      <button
        ref={ref}
        type={type}
        onClick={onClick}
        disabled={disabled}
        className={classes}
      >
        {children}
      </button>
    );
  }
);

Button.displayName = 'Button';
