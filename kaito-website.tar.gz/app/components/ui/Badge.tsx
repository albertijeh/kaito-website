import React from 'react';

interface BadgeProps {
  children: React.ReactNode;
  variant?: 'default' | 'purple' | 'outline';
  className?: string;
}

export const Badge: React.FC<BadgeProps> = ({
  children,
  variant = 'default',
  className = '',
}) => {
  const variants = {
    default:
      'bg-kaito-bg-darker text-kaito-text-secondary border border-kaito-border',
    purple:
      'bg-kaito-purple/10 text-kaito-purple border border-kaito-purple/30',
    outline:
      'bg-transparent text-kaito-text-secondary border border-kaito-border',
  };

  return (
    <span
      className={`inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-medium tracking-wide ${variants[variant]} ${className}`}
    >
      {children}
    </span>
  );
};
