'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { Menu, X } from 'lucide-react';
import { Button } from './ui/Button';

export const Header: React.FC = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navItems = [
    { label: 'Plataforma', href: '#plataforma' },
    { label: 'Soluções', href: '#solucoes' },
    { label: 'Inteligência Artificial', href: '#ia' },
    { label: 'Segmentos', href: '#segmentos' },
    { label: 'Conteúdos', href: '#conteudos' },
  ];

  return (
    <header
      className={`fixed top-0 w-full z-50 transition-all duration-300 ${
        isScrolled
          ? 'bg-kaito-bg-dark/80 backdrop-blur-md border-b border-kaito-border'
          : 'bg-transparent'
      }`}
    >
      <nav className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
        {/* Logo */}
        <Link href="/" className="flex items-center gap-2 group">
          <div className="w-8 h-8 bg-gradient-to-br from-kaito-purple to-kaito-accent rounded-lg flex items-center justify-center">
            <span className="text-white font-bold text-sm">K</span>
          </div>
          <span className="font-bold text-xl text-kaito-fg-light group-hover:text-kaito-purple transition-colors">
            Kaito
          </span>
        </Link>

        {/* Desktop Navigation */}
        <div className="hidden md:flex items-center gap-8">
          {navItems.map((item) => (
            <Link
              key={item.label}
              href={item.href}
              className="text-kaito-text-secondary hover:text-kaito-fg-light transition-colors text-sm font-medium"
            >
              {item.label}
            </Link>
          ))}
        </div>

        {/* Desktop CTA */}
        <div className="hidden md:flex items-center gap-4">
          <Button variant="ghost" size="md" href="#" className="text-sm">
            Entrar
          </Button>
          <Button variant="primary" size="md" href="#demo" className="text-sm">
            Solicitar demonstração
          </Button>
        </div>

        {/* Mobile Menu Button */}
        <button
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          className="md:hidden p-2 text-kaito-text-secondary hover:text-kaito-fg-light transition-colors"
          aria-label="Menu"
        >
          {isMobileMenuOpen ? (
            <X size={24} />
          ) : (
            <Menu size={24} />
          )}
        </button>
      </nav>

      {/* Mobile Menu */}
      {isMobileMenuOpen && (
        <div className="md:hidden border-t border-kaito-border bg-kaito-bg-dark/95 backdrop-blur-md">
          <div className="px-4 py-6 space-y-4">
            {navItems.map((item) => (
              <Link
                key={item.label}
                href={item.href}
                className="block text-kaito-text-secondary hover:text-kaito-fg-light transition-colors py-2"
                onClick={() => setIsMobileMenuOpen(false)}
              >
                {item.label}
              </Link>
            ))}
            <div className="flex flex-col gap-3 pt-4 border-t border-kaito-border">
              <Button
                variant="secondary"
                size="md"
                href="#"
                className="w-full justify-center"
              >
                Entrar
              </Button>
              <Button
                variant="primary"
                size="md"
                href="#demo"
                className="w-full justify-center"
              >
                Solicitar demonstração
              </Button>
            </div>
          </div>
        </div>
      )}
    </header>
  );
};
