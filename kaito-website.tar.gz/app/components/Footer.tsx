import React from 'react';
import Link from 'next/link';
import { Mail, Linkedin, Twitter } from 'lucide-react';

export const Footer: React.FC = () => {
  const currentYear = new Date().getFullYear();

  const footerLinks = {
    Produto: [
      { label: 'Plataforma', href: '#plataforma' },
      { label: 'Inteligência Artificial', href: '#ia' },
      { label: 'CRM', href: '#crm' },
      { label: 'Automação', href: '#automacao' },
    ],
    Empresa: [
      { label: 'Sobre', href: '/about' },
      { label: 'Blog', href: '/blog' },
      { label: 'Contato', href: '#contact' },
      { label: 'Carreira', href: '/careers' },
    ],
    Legal: [
      { label: 'Privacidade', href: '/privacy' },
      { label: 'Termos de Uso', href: '/terms' },
      { label: 'Cookies', href: '/cookies' },
      { label: 'Segurança', href: '/security' },
    ],
  };

  return (
    <footer className="bg-kaito-bg-darker border-t border-kaito-border">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Main Footer Content */}
        <div className="py-16 grid md:grid-cols-4 gap-8">
          {/* Brand */}
          <div className="md:col-span-1">
            <Link href="/" className="flex items-center gap-2 mb-6 group">
              <div className="w-8 h-8 bg-gradient-to-br from-kaito-purple to-kaito-accent rounded-lg flex items-center justify-center">
                <span className="text-white font-bold text-sm">K</span>
              </div>
              <span className="font-bold text-xl text-kaito-fg-light group-hover:text-kaito-purple transition-colors">
                Kaito
              </span>
            </Link>
            <p className="text-kaito-text-secondary text-sm mb-6 leading-relaxed">
              Customer Intelligence platform powered by AI. Transforme relacionamento com clientes em vantagem competitiva.
            </p>
            <div className="flex items-center gap-4">
              <a
                href="https://twitter.com/kaiocorp"
                target="_blank"
                rel="noopener noreferrer"
                className="text-kaito-text-secondary hover:text-kaito-purple transition-colors"
                aria-label="Twitter"
              >
                <Twitter size={20} />
              </a>
              <a
                href="https://linkedin.com/company/kaio"
                target="_blank"
                rel="noopener noreferrer"
                className="text-kaito-text-secondary hover:text-kaito-purple transition-colors"
                aria-label="LinkedIn"
              >
                <Linkedin size={20} />
              </a>
              <a
                href="mailto:contato@kaito.com"
                className="text-kaito-text-secondary hover:text-kaito-purple transition-colors"
                aria-label="Email"
              >
                <Mail size={20} />
              </a>
            </div>
          </div>

          {/* Links Columns */}
          {Object.entries(footerLinks).map(([category, links]) => (
            <div key={category}>
              <h3 className="font-semibold text-kaito-fg-light mb-4">
                {category}
              </h3>
              <ul className="space-y-3">
                {links.map((link) => (
                  <li key={link.href}>
                    <Link
                      href={link.href}
                      className="text-kaito-text-secondary hover:text-kaito-fg-light transition-colors text-sm"
                    >
                      {link.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* Bottom Footer */}
        <div className="py-8 border-t border-kaito-border flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-kaito-text-secondary text-sm">
            © {currentYear} Kaito. Todos os direitos reservados.
          </p>
          <p className="text-kaito-text-secondary text-sm">
            Sinais. Inteligência. Ação.
          </p>
        </div>
      </div>
    </footer>
  );
};
