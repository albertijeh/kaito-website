'use client';

import React from 'react';
import { motion } from 'framer-motion';

export const Manifesto: React.FC = () => {
  const lines = [
    'Dados não vendem sozinhos.',
    '',
    'Uma mensagem pode ser um sinal.',
    'Um áudio pode revelar uma intenção.',
    'Uma imagem pode mostrar um interesse.',
    'Uma resposta pode indicar que chegou a hora de agir.',
    '',
    'Quando esses acontecimentos vivem separados, são apenas dados.',
    '',
    'Quando ganham contexto, tornam-se inteligência.',
    '',
    'E quando inteligência encontra execução, surgem oportunidades.',
  ];

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.05,
        delayChildren: 0.2,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 10 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.6, ease: 'easeOut' },
    },
  };

  return (
    <section className="py-32 px-4 sm:px-6 lg:px-8 relative overflow-hidden">
      {/* Background gradient */}
      <div className="absolute inset-0 -z-10">
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-kaito-purple/5 to-transparent" />
        <div className="absolute top-1/2 right-0 w-96 h-96 bg-kaito-purple/10 rounded-full blur-3xl opacity-30" />
        <div className="absolute top-1/2 left-0 w-96 h-96 bg-kaito-accent/10 rounded-full blur-3xl opacity-20" />
      </div>

      <motion.div
        variants={containerVariants}
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true }}
        className="max-w-4xl mx-auto"
      >
        <div className="text-center lg:text-left">
          {lines.map((line, index) => (
            <motion.p
              key={index}
              variants={itemVariants}
              className={`${
                line === ''
                  ? 'h-6'
                  : 'text-2xl md:text-3xl lg:text-4xl leading-relaxed font-light'
              } ${
                index > 6 && line !== ''
                  ? 'text-kaito-fg-light font-normal'
                  : 'text-kaito-text-secondary'
              }`}
            >
              {line}
            </motion.p>
          ))}
        </div>

        {/* Signature */}
        <motion.div
          variants={itemVariants}
          className="mt-16 pt-12 border-t border-kaito-border"
        >
          <div className="flex flex-col items-center lg:items-start gap-4">
            <div className="w-20 h-20 bg-gradient-to-br from-kaito-purple to-kaito-accent rounded-lg flex items-center justify-center">
              <span className="text-white font-bold text-2xl">K</span>
            </div>
            <div>
              <h3 className="text-3xl font-bold text-kaito-fg-light mb-2">
                KAITO
              </h3>
              <p className="text-xl text-kaito-purple font-medium tracking-wider">
                Sinais. Inteligência. Ação.
              </p>
            </div>
          </div>
        </motion.div>
      </motion.div>
    </section>
  );
};
