'use client';

import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { SectionHeader } from '../ui/SectionHeader';
import {
  Eye,
  Headphones,
  Brain,
  MessageCircle,
  Phone,
  TrendingUp,
  Calendar,
  Zap,
} from 'lucide-react';

export const KaitoAI: React.FC = () => {
  const [activeStep, setActiveStep] = useState(0);

  const steps = [
    {
      icon: Eye,
      title: 'Ela lê.',
      description: 'Interpreta imagens e conteúdo visual',
      visual: 'Imagem chegando...',
      color: 'from-kaito-purple-lighter',
    },
    {
      icon: Headphones,
      title: 'Ela escuta.',
      description: 'Transcreve e compreende áudios',
      visual: 'Transcrevendo áudio...',
      color: 'from-kaito-purple-light',
    },
    {
      icon: Brain,
      title: 'Ela entende.',
      description: 'Identifica intenção e contexto',
      visual: 'Analisando intenção...',
      color: 'from-kaito-accent',
    },
    {
      icon: MessageCircle,
      title: 'Ela conversa.',
      description: 'Dialoga naturalmente com leads',
      visual: 'Iniciando conversa...',
      color: 'from-kaito-purple',
    },
    {
      icon: Phone,
      title: 'Ela liga.',
      description: 'Realiza e registra chamadas',
      visual: 'Ligação iniciada...',
      color: 'from-kaito-purple-lighter',
    },
    {
      icon: TrendingUp,
      title: 'Ela prioriza.',
      description: 'Classifica leads por potencial',
      visual: 'Calculando Lead Score...',
      color: 'from-kaito-accent',
    },
    {
      icon: Calendar,
      title: 'Ela agenda.',
      description: 'Agendar reuniões automaticamente',
      visual: 'Verificando disponibilidade...',
      color: 'from-kaito-purple-light',
    },
    {
      icon: Zap,
      title: 'Ela age.',
      description: 'Executa próximas ações automáticas',
      visual: 'Gerando ação recomendada...',
      color: 'from-kaito-purple',
    },
  ];

  return (
    <section className="py-24 px-4 sm:px-6 lg:px-8 relative overflow-hidden">
      {/* Background elements */}
      <div className="absolute inset-0 -z-10">
        <div className="absolute top-1/4 left-0 w-96 h-96 bg-kaito-purple/15 rounded-full blur-3xl opacity-30" />
        <div className="absolute bottom-1/4 right-0 w-96 h-96 bg-kaito-accent/10 rounded-full blur-3xl opacity-20" />
      </div>

      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
        >
          <SectionHeader
            eyebrow="Kaito AI"
            title="Uma IA que lê, escuta, conversa e age."
            description="Clientes não se comunicam apenas digitando. Eles mandam mensagens, áudios, imagens, fazem perguntas, demonstram interesse. A Kaito AI foi criada para compreender esse contexto em tempo real."
          />
        </motion.div>

        {/* AI Capabilities Flow */}
        <div className="mt-20">
          {/* Desktop View - Grid */}
          <div className="hidden lg:grid grid-cols-4 gap-4">
            {steps.map((step, index) => {
              const Icon = step.icon;
              const isActive = activeStep === index;

              return (
                <motion.button
                  key={index}
                  onClick={() => setActiveStep(index)}
                  className={`p-6 rounded-lg border transition-all duration-300 cursor-pointer ${
                    isActive
                      ? 'bg-kaito-bg-darker border-kaito-purple'
                      : 'bg-kaito-bg-darkest border-kaito-border hover:border-kaito-purple/50'
                  }`}
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.98 }}
                >
                  <div
                    className={`w-12 h-12 rounded-lg bg-gradient-to-br ${step.color} to-kaito-accent/50 flex items-center justify-center mb-4 mx-auto`}
                  >
                    <Icon size={24} className="text-white" />
                  </div>
                  <h3 className="font-semibold text-kaito-fg-light mb-2">
                    {step.title}
                  </h3>
                  <p className="text-sm text-kaito-text-secondary">
                    {step.description}
                  </p>
                </motion.button>
              );
            })}
          </div>

          {/* Mobile View - Carousel */}
          <div className="lg:hidden">
            <div className="space-y-4">
              {steps.map((step, index) => {
                const Icon = step.icon;
                return (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, y: 10 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.1 }}
                    viewport={{ once: true }}
                    className="p-6 bg-kaito-bg-darker border border-kaito-border rounded-lg"
                  >
                    <div className="flex items-start gap-4">
                      <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-kaito-purple to-kaito-accent flex items-center justify-center flex-shrink-0">
                        <Icon size={24} className="text-white" />
                      </div>
                      <div>
                        <h3 className="font-semibold text-kaito-fg-light mb-1">
                          {step.title}
                        </h3>
                        <p className="text-sm text-kaito-text-secondary">
                          {step.description}
                        </p>
                      </div>
                    </div>
                  </motion.div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Feature Highlight */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          viewport={{ once: true }}
          className="mt-20 text-center max-w-3xl mx-auto"
        >
          <div className="bg-kaito-bg-darker border border-kaito-purple/30 rounded-xl p-8">
            <h3 className="text-2xl font-bold text-kaito-fg-light mb-4">
              Não é apenas IA generativa.
            </h3>
            <p className="text-lg text-kaito-text-secondary">
              É inteligência conectada à operação comercial.
            </p>
          </div>
        </motion.div>

        {/* Final Message */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.4 }}
          viewport={{ once: true }}
          className="mt-16 text-center"
        >
          <p className="text-2xl md:text-3xl font-bold text-kaito-fg-light">
            E sua equipe entra quando realmente{' '}
            <span className="text-kaito-purple">importa.</span>
          </p>
        </motion.div>
      </div>
    </section>
  );
};
