'use client';

import React from 'react';
import { motion } from 'framer-motion';
import { Badge } from '../ui/Badge';
import { Button } from '../ui/Button';
import { ArrowRight } from 'lucide-react';

export const Hero: React.FC = () => {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2,
        delayChildren: 0.3,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.8, ease: 'easeOut' },
    },
  };

  return (
    <section className="min-h-screen flex items-center justify-center relative overflow-hidden pt-20">
      {/* Background gradient */}
      <div className="absolute inset-0 -z-10">
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-96 h-96 bg-kaito-purple/20 rounded-full blur-3xl opacity-30" />
        <div className="absolute bottom-0 right-0 w-96 h-96 bg-kaito-accent/10 rounded-full blur-3xl opacity-20" />
      </div>

      <motion.div
        variants={containerVariants}
        initial="hidden"
        animate="visible"
        className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12"
      >
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Left Content */}
          <div className="space-y-8">
            <motion.div variants={itemVariants}>
              <Badge variant="purple">Customer Intelligence + AI</Badge>
            </motion.div>

            <motion.h1
              variants={itemVariants}
              className="text-5xl md:text-6xl lg:text-7xl font-bold tracking-tighter leading-tight"
            >
              Entenda cada sinal.{' '}
              <span className="bg-gradient-to-r from-kaito-purple via-kaito-accent to-kaito-purple-lighter bg-clip-text text-transparent">
                Transforme inteligência em ação.
              </span>
            </motion.h1>

            <motion.p
              variants={itemVariants}
              className="text-lg text-kaito-text-secondary leading-relaxed max-w-xl"
            >
              A Kaito conecta CRM, inteligência artificial, automação e dados da
              jornada para ajudar sua empresa a atrair, converter e se relacionar
              melhor com cada cliente.
            </motion.p>

            <motion.p
              variants={itemVariants}
              className="text-base text-kaito-text-secondary/80"
            >
              Da primeira interação à venda — e da venda ao próximo relacionamento.
            </motion.p>

            <motion.div variants={itemVariants} className="flex flex-col sm:flex-row gap-4 pt-4">
              <Button
                variant="primary"
                size="lg"
                href="#demo"
                className="group"
              >
                Ver a Kaito em ação
                <ArrowRight size={20} className="group-hover:translate-x-1 transition-transform" />
              </Button>
              <Button
                variant="secondary"
                size="lg"
                href="#contact"
              >
                Solicitar demonstração
              </Button>
            </motion.div>

            <motion.p
              variants={itemVariants}
              className="text-sm text-kaito-text-secondary/60"
            >
              Customer Intelligence. Powered by AI.
            </motion.p>
          </div>

          {/* Right Visual - Product Window */}
          <motion.div
            variants={itemVariants}
            className="relative h-96 md:h-full min-h-96 flex items-center"
          >
            <div className="w-full bg-gradient-to-br from-kaito-bg-darker to-kaito-bg-darkest border border-kaito-border rounded-2xl p-6 shadow-2xl">
              {/* Mock Product Card */}
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 rounded-full bg-gradient-to-br from-kaito-purple to-kaito-accent" />
                    <div>
                      <p className="font-semibold text-kaito-fg-light">
                        Mariana Costa
                      </p>
                      <p className="text-sm text-kaito-text-secondary">
                        Lead Qualificado
                      </p>
                    </div>
                  </div>
                  <div className="px-3 py-1 bg-kaito-purple/20 border border-kaito-purple/50 rounded-full text-xs text-kaito-purple">
                    Super Quente
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div className="bg-kaito-bg-dark rounded-lg p-3">
                    <p className="text-xs text-kaito-text-secondary mb-1">
                      Origem
                    </p>
                    <p className="text-sm font-medium text-kaito-fg-light">
                      Campanha digital
                    </p>
                  </div>
                  <div className="bg-kaito-bg-dark rounded-lg p-3">
                    <p className="text-xs text-kaito-text-secondary mb-1">
                      Última interação
                    </p>
                    <p className="text-sm font-medium text-kaito-fg-light">
                      Áudio agora
                    </p>
                  </div>
                </div>

                <div className="bg-kaito-bg-dark rounded-lg p-4 border border-kaito-purple/30">
                  <p className="text-xs text-kaito-purple mb-2 font-medium">
                    KAITO AI INSIGHT
                  </p>
                  <p className="text-sm text-kaito-fg-light">
                    "Demonstrou interesse e perguntou sobre disponibilidade para
                    visita."
                  </p>
                </div>

                <div className="flex items-center justify-between pt-2">
                  <p className="text-xs text-kaito-text-secondary">
                    Próxima ação sugerida
                  </p>
                  <button className="text-xs font-medium text-kaito-purple hover:text-kaito-accent transition-colors">
                    Encaminhar para vendedor →
                  </button>
                </div>
              </div>
            </div>

            {/* Floating element */}
            <motion.div
              animate={{ y: [0, -10, 0] }}
              transition={{ duration: 3, repeat: Infinity }}
              className="absolute top-0 right-0 w-20 h-20 bg-kaito-purple/10 border border-kaito-purple/30 rounded-lg"
            />
          </motion.div>
        </div>
      </motion.div>
    </section>
  );
};
