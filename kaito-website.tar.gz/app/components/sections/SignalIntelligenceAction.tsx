'use client';

import React from 'react';
import { motion } from 'framer-motion';
import { SectionHeader } from '../ui/SectionHeader';
import {
  Radio,
  Lightbulb,
  Zap,
  MessageCircle,
  Image,
  Music,
  Phone,
  CheckCircle,
} from 'lucide-react';

export const SignalIntelligenceAction: React.FC = () => {
  const signals = [
    { icon: MessageCircle, label: 'Mensagem' },
    { icon: Music, label: 'Áudio' },
    { icon: Image, label: 'Imagem' },
    { icon: CheckCircle, label: 'Clique' },
    { icon: MessageCircle, label: 'Resposta' },
    { icon: Phone, label: 'Ligação' },
  ];

  const actions = [
    'Responder',
    'Priorizar',
    'Segmentar',
    'Agendar',
    'Criar tarefa',
    'Acionar vendedor',
    'Iniciar automação',
    'Fazer follow-up',
    'Reativar',
  ];

  return (
    <section className="py-24 px-4 sm:px-6 lg:px-8 relative overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 -z-10">
        <div className="absolute inset-0 bg-gradient-to-b from-kaito-purple/5 to-transparent" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-full h-full max-w-4xl bg-kaito-purple/10 rounded-full blur-3xl opacity-20" />
      </div>

      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
        >
          <SectionHeader
            eyebrow="A lógica por trás da inteligência"
            title="Dos sinais à próxima melhor ação."
          />
        </motion.div>

        {/* Three Pillar Flow */}
        <div className="mt-20 grid lg:grid-cols-3 gap-8 items-stretch">
          {/* SINAIS */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0 }}
            viewport={{ once: true }}
            className="bg-kaito-bg-darker border border-kaito-border rounded-2xl p-8"
          >
            <div className="flex items-center gap-3 mb-6">
              <Radio size={28} className="text-kaito-purple" />
              <h3 className="text-2xl font-bold text-kaito-fg-light">
                SINAIS
              </h3>
            </div>

            <p className="text-kaito-text-secondary mb-8 leading-relaxed">
              Cada interação pode revelar algo sobre sua intenção, interesse ou
              momento.
            </p>

            <div className="space-y-3">
              {signals.map((signal, index) => {
                const Icon = signal.icon;
                return (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, x: -10 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    transition={{ delay: index * 0.1 }}
                    viewport={{ once: true }}
                    className="flex items-center gap-3 p-3 bg-kaito-bg-dark rounded-lg hover:border border-kaito-border/50 transition-all"
                  >
                    <Icon size={20} className="text-kaito-purple flex-shrink-0" />
                    <span className="text-kaito-text-secondary">
                      {signal.label}
                    </span>
                  </motion.div>
                );
              })}
            </div>
          </motion.div>

          {/* INTELIGÊNCIA */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            viewport={{ once: true }}
            className="bg-kaito-bg-darker border border-kaito-border rounded-2xl p-8"
          >
            <div className="flex items-center gap-3 mb-6">
              <Lightbulb size={28} className="text-kaito-accent" />
              <h3 className="text-2xl font-bold text-kaito-fg-light">
                INTELIGÊNCIA
              </h3>
            </div>

            <p className="text-kaito-text-secondary mb-8 leading-relaxed">
              A Kaito conecta esses acontecimentos ao contexto da jornada para
              identificar padrões, mudanças de comportamento e oportunidades
              reais.
            </p>

            <div className="space-y-2 text-kaito-text-secondary text-sm leading-relaxed">
              <p>✓ Analisar intenção</p>
              <p>✓ Compreender contexto</p>
              <p>✓ Identificar padrões</p>
              <p>✓ Detectar oportunidades</p>
              <p>✓ Avaliar temperatura</p>
              <p>✓ Classificar leads</p>
            </div>
          </motion.div>

          {/* AÇÃO */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
            viewport={{ once: true }}
            className="bg-kaito-bg-darker border border-kaito-border rounded-2xl p-8"
          >
            <div className="flex items-center gap-3 mb-6">
              <Zap size={28} className="text-kaito-purple-light" />
              <h3 className="text-2xl font-bold text-kaito-fg-light">AÇÃO</h3>
            </div>

            <p className="text-kaito-text-secondary mb-8 leading-relaxed">
              A inteligência pode gerar uma próxima etapa automática, preparando
              sua equipe para o momento certo.
            </p>

            <div className="grid grid-cols-2 gap-2">
              {actions.map((action, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, scale: 0.9 }}
                  whileInView={{ opacity: 1, scale: 1 }}
                  transition={{ delay: index * 0.05 }}
                  viewport={{ once: true }}
                  className="px-3 py-2 bg-kaito-purple/10 border border-kaito-purple/30 rounded-lg text-sm text-kaito-purple hover:bg-kaito-purple/20 transition-colors"
                >
                  {action}
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>

        {/* Central Message */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.6 }}
          viewport={{ once: true }}
          className="mt-20 text-center max-w-3xl mx-auto"
        >
          <div className="bg-gradient-to-r from-kaito-purple/10 to-kaito-accent/10 border border-kaito-purple/30 rounded-2xl p-8">
            <p className="text-xl text-kaito-fg-light font-semibold mb-3">
              Dados mostram o que aconteceu.
            </p>
            <p className="text-lg text-kaito-text-secondary">
              Inteligência ajuda a decidir o que fazer depois.
            </p>
          </div>
        </motion.div>
      </div>
    </section>
  );
};
