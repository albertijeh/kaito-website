'use client';

import React from 'react';
import { motion } from 'framer-motion';
import { SectionHeader } from '../ui/SectionHeader';
import {
  Megaphone,
  Target,
  Heart,
  BarChart3,
} from 'lucide-react';

export const ProductOverview: React.FC = () => {
  const pillars = [
    {
      title: 'ATRair',
      subtitle: 'Transforme atenção em relacionamento.',
      description:
        'Comunique, qualifique, relacione e nutra líderes ao longo do funil inicial.',
      features: [
        'Campanhas de e-mail',
        'WhatsApp marketing',
        'Segmentação',
        'Nutrição de leads',
        'Automações',
        'Comunicação por canal',
      ],
      icon: Megaphone,
      color: 'from-kaito-purple-lighter',
    },
    {
      title: 'CONVERTER',
      subtitle: 'Dê inteligência à operação comercial.',
      description:
        'Qualifique, priorize, execute e converta oportunidades com contexto completo.',
      features: [
        'Qualificação automática',
        'Lead Score',
        'Classificação de leads',
        'Kanban personalizado',
        'Oportunidades',
        'Agenda comercial',
      ],
      icon: Target,
      color: 'from-kaito-accent',
    },
    {
      title: 'RELACIONAR',
      subtitle: 'Continue a jornada depois da conversão.',
      description:
        'Atenda, acompanhe e reative — transformando clientes em relacionamentos duradouros.',
      features: [
        'Atendimento integrado',
        'Histórico completo',
        'Pós-visita automático',
        'Pós-venda',
        'Satisfação',
        'Reativação',
      ],
      icon: Heart,
      color: 'from-kaito-purple-light',
    },
    {
      title: 'INTELIGÊNCIA',
      subtitle: 'Descubra o que seus dados estão tentando dizer.',
      description:
        'Analise, compreenda comportamento e tome decisões baseadas em dados reais.',
      features: [
        'Kaito AI integrada',
        'Análise de imagens',
        'Transcrição de áudio',
        'Classificação automática',
        'Relatórios executivos',
        'Performance comercial',
      ],
      icon: BarChart3,
      color: 'from-kaito-purple',
    },
  ];

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
        delayChildren: 0.2,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.8, ease: 'easeOut' },
    },
  };

  return (
    <section className="py-24 px-4 sm:px-6 lg:px-8 relative">
      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
        >
          <SectionHeader
            eyebrow="Uma plataforma. Toda a jornada."
            title="Da primeira interação à próxima oportunidade."
          />
        </motion.div>

        {/* Pillars Grid */}
        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          className="mt-16 grid lg:grid-cols-2 gap-6"
        >
          {pillars.map((pillar, index) => {
            const Icon = pillar.icon;
            return (
              <motion.div
                key={index}
                variants={itemVariants}
                className="group"
              >
                <div className="bg-kaito-bg-darker border border-kaito-border rounded-2xl p-8 h-full hover:border-kaito-purple/50 transition-all duration-300">
                  {/* Icon */}
                  <div
                    className={`w-14 h-14 rounded-lg bg-gradient-to-br ${pillar.color} to-kaito-accent/50 flex items-center justify-center mb-6 group-hover:scale-110 transition-transform`}
                  >
                    <Icon size={28} className="text-white" />
                  </div>

                  {/* Title */}
                  <h3 className="text-2xl font-bold mb-2 text-kaito-fg-light">
                    {pillar.title}
                  </h3>
                  <p className="text-lg text-kaito-text-secondary mb-4 font-medium">
                    {pillar.subtitle}
                  </p>

                  {/* Description */}
                  <p className="text-kaito-text-secondary mb-6 leading-relaxed">
                    {pillar.description}
                  </p>

                  {/* Features Grid */}
                  <div className="grid grid-cols-2 gap-3">
                    {pillar.features.map((feature, featureIdx) => (
                      <div
                        key={featureIdx}
                        className="flex items-center gap-2 text-sm"
                      >
                        <div className="w-2 h-2 rounded-full bg-kaito-purple flex-shrink-0" />
                        <span className="text-kaito-text-secondary">
                          {feature}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              </motion.div>
            );
          })}
        </motion.div>
      </div>
    </section>
  );
};
