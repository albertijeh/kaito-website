'use client';

import React from 'react';
import { motion } from 'framer-motion';
import { SectionHeader } from '../ui/SectionHeader';
import { Mail, Users, Phone, TrendingUp } from 'lucide-react';

export const SingleJourney: React.FC = () => {
  const departments = [
    {
      name: 'Marketing',
      description: 'Gera interesse',
      icon: Mail,
      color: 'from-kaito-purple-lighter',
    },
    {
      name: 'Vendas',
      description: 'Transforma em oportunidade',
      icon: Users,
      color: 'from-kaito-purple-light',
    },
    {
      name: 'Atendimento',
      description: 'Resolve necessidades',
      icon: Phone,
      color: 'from-kaito-accent',
    },
    {
      name: 'Pós-venda',
      description: 'Constrói relacionamento',
      icon: TrendingUp,
      color: 'from-kaito-purple',
    },
  ];

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
        delayChildren: 0.2,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.8, ease: 'easeOut' },
    },
  };

  return (
    <section className="py-24 px-4 sm:px-6 lg:px-8 relative">
      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
        >
          <SectionHeader
            eyebrow="Uma única jornada"
            title="Seus clientes não enxergam departamentos. Sua tecnologia também não deveria."
            description="Seus clientes vivem uma experiência contínua. A Kaito conecta essas etapas em uma jornada unificada."
          />
        </motion.div>

        {/* Journey Flow */}
        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          className="mt-16"
        >
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {departments.map((dept, index) => {
              const Icon = dept.icon;
              return (
                <motion.div
                  key={dept.name}
                  variants={itemVariants}
                  className="relative group"
                >
                  <div className="bg-kaito-bg-darker border border-kaito-border rounded-xl p-6 h-full hover:border-kaito-purple/50 transition-all duration-300">
                    <div
                      className={`w-12 h-12 rounded-lg bg-gradient-to-br ${dept.color} to-kaito-accent/50 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform`}
                    >
                      <Icon size={24} className="text-white" />
                    </div>
                    <h3 className="text-lg font-semibold mb-2 text-kaito-fg-light">
                      {dept.name}
                    </h3>
                    <p className="text-kaito-text-secondary">
                      {dept.description}
                    </p>
                  </div>

                  {/* Arrow to next */}
                  {index < departments.length - 1 && (
                    <div className="hidden lg:block absolute -right-3 top-1/2 -translate-y-1/2">
                      <div className="w-6 h-6 rounded-full border border-kaito-border bg-kaito-bg-dark flex items-center justify-center">
                        <svg
                          className="w-4 h-4 text-kaito-purple"
                          fill="none"
                          stroke="currentColor"
                          viewBox="0 0 24 24"
                        >
                          <path
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            strokeWidth={2}
                            d="M9 5l7 7-7 7"
                          />
                        </svg>
                      </div>
                    </div>
                  )}
                </motion.div>
              );
            })}
          </div>
        </motion.div>

        {/* Central Message */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.4 }}
          viewport={{ once: true }}
          className="mt-16 text-center"
        >
          <p className="text-kaito-text-secondary mb-6 text-lg">Converge para:</p>
          <div className="inline-block">
            <h2 className="text-4xl md:text-5xl font-bold">
              <span className="bg-gradient-to-r from-kaito-purple via-kaito-accent to-kaito-purple-lighter bg-clip-text text-transparent">
                KAITO INTELLIGENCE
              </span>
            </h2>
          </div>
          <p className="text-kaito-text-secondary mt-6 max-w-2xl mx-auto">
            A Kaito conecta informações, interações e equipes para transformar
            dados dispersos em contexto e inteligência comercial.
          </p>
        </motion.div>
      </div>
    </section>
  );
};
