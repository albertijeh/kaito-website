'use client';

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { SectionHeader } from '../ui/SectionHeader';
import { ChevronDown } from 'lucide-react';

interface FAQItem {
  question: string;
  answer: string;
}

export const FAQ: React.FC = () => {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  const faqs: FAQItem[] = [
    {
      question: 'O que é um CRM com IA?',
      answer:
        'Um CRM com IA combina gestão do relacionamento com clientes e inteligência artificial para organizar dados, interpretar informações, identificar padrões e apoiar decisões comerciais em tempo real. A Kaito vai além: conecta CRM, automação e operação comercial em uma única plataforma.',
    },
    {
      question: 'O que é Customer Intelligence?',
      answer:
        'Customer Intelligence consiste em utilizar dados e interações dos clientes para compreender comportamentos, necessidades, histórico e oportunidades ao longo da jornada. A Kaito transforma dados dispersos em inteligência conectada à operação comercial.',
    },
    {
      question: 'Qual a diferença entre CRM e Customer Intelligence?',
      answer:
        'O CRM organiza informações e processos relacionados aos clientes. Customer Intelligence utiliza essas informações para gerar contexto, identificar padrões e ajudar empresas a decidir o que fazer a seguir. A Kaito conecta esses dois conceitos em uma plataforma integrada.',
    },
    {
      question: 'A Kaito AI é apenas um chatbot?',
      answer:
        'Não. A Kaito AI não é um chatbot genérico. Ela funciona como parte integrada da sua operação comercial — compreende o contexto de cada cliente, interpreta intenção a partir de áudios e imagens, automatiza qualificação e recomenda a próxima melhor ação para seu time.',
    },
    {
      question: 'Como a IA pode ajudar equipes de vendas?',
      answer:
        'A IA pode interpretar interações, identificar sinais de interesse, apoiar qualificação, priorizar oportunidades, automatizar tarefas e oferecer mais contexto para vendedores. Na Kaito, ela trabalha com toda a jornada, não apenas com leads avulsos.',
    },
    {
      question: 'A Kaito consegue analisar imagens?',
      answer:
        'Sim. A Kaito AI possui capacidade de interpretar imagens como parte das informações recebidas durante uma interação, ajudando a compreender intenção e contexto do cliente.',
    },
    {
      question: 'A Kaito possui automações?',
      answer:
        'Sim. A Kaito permite criar automações relacionadas à jornada e às etapas do funil, incluindo ações de relacionamento, comunicação, qualificação automática e até agendamento de reuniões.',
    },
    {
      question: 'A Kaito trabalha com WhatsApp e e-mail?',
      answer:
        'Sim. A Kaito integra WhatsApp para conversas e automações de relacionamento, além de campanhas e disparos de e-mail marketing com inteligência sobre o momento de cada lead.',
    },
  ];

  return (
    <section className="py-24 px-4 sm:px-6 lg:px-8 relative">
      <div className="max-w-4xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
        >
          <SectionHeader
            eyebrow="Dúvidas frequentes"
            title="Perguntas sobre CRM, IA e Customer Intelligence"
            centered={true}
          />
        </motion.div>

        {/* FAQ Items */}
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          viewport={{ once: true }}
          className="mt-12 space-y-4"
        >
          {faqs.map((faq, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 10 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.05 }}
              viewport={{ once: true }}
              className="border border-kaito-border rounded-lg overflow-hidden hover:border-kaito-purple/50 transition-all"
            >
              <button
                onClick={() =>
                  setOpenIndex(openIndex === index ? null : index)
                }
                className="w-full px-6 py-5 flex items-center justify-between bg-kaito-bg-darker hover:bg-kaito-bg-darkest transition-colors text-left"
              >
                <h3 className="text-lg font-semibold text-kaito-fg-light pr-4">
                  {faq.question}
                </h3>
                <motion.div
                  animate={{ rotate: openIndex === index ? 180 : 0 }}
                  transition={{ duration: 0.3 }}
                  className="flex-shrink-0"
                >
                  <ChevronDown
                    size={20}
                    className="text-kaito-purple"
                  />
                </motion.div>
              </button>

              <AnimatePresence>
                {openIndex === index && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: 'auto', opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    transition={{ duration: 0.3 }}
                    className="overflow-hidden"
                  >
                    <div className="px-6 py-5 bg-kaito-bg-darkest border-t border-kaito-border">
                      <p className="text-kaito-text-secondary leading-relaxed">
                        {faq.answer}
                      </p>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
};
